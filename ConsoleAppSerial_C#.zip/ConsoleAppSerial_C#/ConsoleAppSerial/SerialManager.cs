﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppSerial
{
    public class SerialManager
    {
        UartBuffer m_buffer;
        public void OpenSerial(UartBuffer buffer)
        {
            m_buffer = buffer;
        }


        private void charArrived()
        {
            m_buffer.addChar(0x01);
        }

        public void CloseSerial()
        {

        }
    }
}
