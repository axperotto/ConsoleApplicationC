﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppSerial
{
    public enum UART_MsgComposer_State_t
    {
        WAITING_FOR_BC = 0,
        WAITING_FOR_MSG_COMPLETE = 1,
        MSG_COMPLETE = 2
    }

    public class UART_MsgComposer
    {

        public void AddChar(byte newChar)
        {

        }
    }
}
